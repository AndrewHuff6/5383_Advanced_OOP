# Pygame window skeleton - Week 1 (browser-compatible via Pygbag)
import asyncio
import pygame

pygame.init()

WIDTH, HEIGHT = 1000, 500
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Andrew's Football Game")
clock = pygame.time.Clock()

async def main():
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        screen.fill((34, 139, 34))  # field green
        pygame.display.flip()

        clock.tick(60)
        await asyncio.sleep(0)  # required for the browser build

    pygame.quit()

asyncio.run(main())